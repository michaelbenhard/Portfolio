package ubc.cosc322.heuristic;

import java.lang.Cloneable;

public class Tile implements Cloneable {
	public static final int MOVES = 4;
	public static final int ARROW = 3;
	public static final int BLACK = 2;
	public static final int WHITE = 1;
	public static final int EMPTY = 0;

	public int row, col;
	public int type;

	public Tile(int row, int col) {
		this.row = row;
		this.col = col;
		this.type = EMPTY;
	}

	public Tile(int row, int col, int type) {
		this.row = row;
		this.col = col;
		this.type = type;
	}

	@Override
	protected Tile clone() {
		try {
			return (Tile) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String toString() {
		return "(" + row + ", " + col + ", " + type + ")";
	}
}
