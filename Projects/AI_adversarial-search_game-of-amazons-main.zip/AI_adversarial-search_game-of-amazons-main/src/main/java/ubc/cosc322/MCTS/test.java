package ubc.cosc322.MCTS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import ubc.cosc322.COSC322Test;
import ubc.cosc322.states.Constant;
import ubc.cosc322.states.Move;
import ubc.cosc322.states.State;

public class test {

  public static void main(String[] args) throws Exception {

    int[][] localBoard = {
        { 0, 0, 0, 0, 3, 2, 0, 0, 0, 0 },
        { 0, 0, 0, 3, 3, 3, 3, 3, 0, 0 },
        { 0, 0, 0, 3, 0, 0, 0, 1, 0, 0 },
        { 3, 2, 3, 3, 3, 3, 0, 0, 0, 0 },
        { 3, 3, 3, 3, 3, 0, 0, 0, 1, 0 },
        { 2, 3, 3, 2, 3, 3, 0, 0, 0, 0 },
        { 3, 3, 3, 1, 3, 0, 0, 0, 0, 0 },
        { 0, 1, 0, 0, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 3, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };

    int[][] blackQueens = new int[][] {
        new int[] { 5, 3 },
        new int[] { 0, 5 },
        new int[] { 5, 0 },
        new int[] { 3, 1 },
    };
    int[][] whiteQueens = new int[][] {
        new int[] { 7, 1 },
        new int[] { 6, 3 },
        new int[] { 4, 8 },
        new int[] { 2, 7 },
    };

    State initState = new State();
    initState.setBoard(new int[][] {
        { 0, 0, 0, 2, 1, 3, 2, 3, 3, 0 },
        { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
        { 3, 3, 3, 3, 3, 3, 3, 0, 3, 3 },
        { 2, 3, 3, 3, 3, 3, 3, 3, 3, 2 },
        { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
        { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
        { 1, 3, 3, 3, 3, 3, 3, 3, 3, 1 },
        { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
        { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
        { 0, 0, 0, 1, 0, 0, 1, 0, 3, 0 },
    });
    initState.updateAvailableMoves();
    List<Move> temp = initState.getAvailableMoves();

    MCTS tree = new MCTS(initState, 2);

    final ExecutorService executor = Executors.newSingleThreadExecutor();
    final Future<Object> future = executor.submit(() -> {
      // Do you long running calculation here

      tree.runSearch();
      return "42";
    });

    try {

      System.out.println(future.get(5, TimeUnit.SECONDS));

    } catch (TimeoutException e) {
      future.cancel(true);
    } catch (Exception e) {
      throw new RuntimeException(e);
    } finally {
      executor.shutdown();
    }
    Move bestMove = tree.getBestMove();
    System.out.println(bestMove);

    for (int[] i : localBoard)
      System.out.println(Arrays.toString(i));
    for (int[] i : blackQueens)
      System.out.println(Arrays.toString(i));
    for (int[] i : whiteQueens)
      System.out.println(Arrays.toString(i));
  }

  private static int whosTurn() {
    return Constant.BLACK;
  }
}
