package ubc.cosc322.heuristic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import ubc.cosc322.COSC322Test;

public class GameState {
  public static int myID; // static means this is shared across all states
  public static int maxIterations;
  public int winner;
  public int whosTurn;
  public int reward;
  private int numWins;
  public int numVisits;

  public int[][] board2DArray;
  public List<Tile> blackQueens, whiteQueens;
  public Heuristic heuristic;
  private GameState parent;
  public List<GameState> child;
  public List<Tile[]> availableMoves;

  // constructor for root node
  public GameState(int myID, int maxIterations, int whosTurn) {
    reward = 0;
    GameState.myID = myID;
    GameState.maxIterations = maxIterations;
    this.whosTurn = whosTurn;
    board2DArray = new int[][] {
        { 0, 0, 0, 2, 0, 0, 2, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 },
    };
    blackQueens = new ArrayList<>(
        Arrays.asList(
            new Tile(0, 3, Tile.BLACK),
            new Tile(0, 6, Tile.BLACK),
            new Tile(3, 0, Tile.BLACK),
            new Tile(3, 9, Tile.BLACK)));
    whiteQueens = new ArrayList<>(
        Arrays.asList(
            new Tile(9, 3, Tile.WHITE),
            new Tile(9, 6, Tile.WHITE),
            new Tile(6, 0, Tile.WHITE),
            new Tile(6, 9, Tile.WHITE)));
    heuristic = new Heuristic(board2DArray);
    this.child = new ArrayList<>();
    this.availableMoves = this.getActions();
  }

  public GameState(int[][] initBoard, List<Tile> blackQueens, List<Tile> whiteQueens, int whosTurn, GameState parent) {
    reward = 0;
    board2DArray = Arrays.stream(initBoard).map(int[]::clone).toArray(int[][]::new);
    this.blackQueens = new ArrayList<>();
    for (Tile t : blackQueens) {
      this.blackQueens.add((Tile) t.clone());
    }
    this.whiteQueens = new ArrayList<>();
    for (Tile t : whiteQueens) {
      this.whiteQueens.add((Tile) t.clone());
    }
    this.whosTurn = whosTurn;
    this.availableMoves = this.getActions();
    this.child = new ArrayList<>();
    this.parent = parent;
    heuristic = new Heuristic(board2DArray);
    winner = !isTerminalNode() ? heuristic.whosWinning(myID) : (whosTurn%2) + 1;
  }
  
  public void updateWinner() {
	  winner = !isTerminalNode() ? heuristic.whosWinning(myID) : (whosTurn%2) + 1;
  }

  public int getQueensHeuristic() {
    // TODO: implement getQueensHeuristic()
    // heuristic.minQueenHeur();
    return -1;
  }

  public List<Tile> getQueenPositions() {
    if (whosTurn == Tile.BLACK) {
      return blackQueens;
    }
    return whiteQueens;
  }

  // return -1 if node is not terminal, returns boolean
  public boolean isTerminalNode() {
    // TODO: test isTerminalState()
    List<Tile> queens = null;
    if (whosTurn == Tile.BLACK) {
      queens = blackQueens;
    } else {
      queens = whiteQueens;
    }

    for (Tile queen : queens) {
      // check if any of the 8 directions is available, from north then clockwise
      if ((queen.row - 1 < 0 || board2DArray[queen.row - 1][queen.col] != 0) // check north, then clockwise
          && ((queen.row - 1 < 0 || queen.col + 1 >= 10) || board2DArray[queen.row - 1][queen.col + 1] != 0)
          && (queen.col + 1 >= 10 || board2DArray[queen.row][queen.col + 1] != 0)
          && ((queen.row + 1 >= 10 || queen.col + 1 >= 10) || board2DArray[queen.row + 1][queen.col + 1] != 0)
          && (queen.row + 1 >= 10 || board2DArray[queen.row + 1][queen.col] != 0)
          && ((queen.row + 1 >= 10 || queen.col - 1 < 0) || board2DArray[queen.row + 1][queen.col - 1] != 0)
          && (queen.col - 1 < 0 || board2DArray[queen.row][queen.col - 1] != 0)
          && ((queen.row - 1 < 0 || queen.col - 1 < 0) || board2DArray[queen.row - 1][queen.col - 1] != 0)) {
        return true;
      }
    }

    return false;
  }

  // updating reward and number of visits during backpropagation
  public void updateStats(int outcome) {
    this.reward += outcome;
    numVisits++;
  }

  public double getUCB() {
    // TODO: Optimize this maybe
    if (numVisits == 0)
    	return Integer.MAX_VALUE;
//    	return this.heuristic.ownedBy.get(myID);
//    	if(this.heuristic.ownedBy.get(myID) >= 0)
//    		return 1;
//    	else return -1;
    double temp = (Math.sqrt((Math.log(maxIterations) / numVisits)));
    return ((double) numWins / numVisits) + (Math.sqrt(2) * (Math.sqrt((Math.log(maxIterations) / numVisits))));
  }

  public GameState getBestChildUCB() {
    return Collections.max(child, Comparator.comparing(GameState::getUCB));
  }

  public GameState getParent() {
    return parent;
  }

  public List<GameState> getChild() {
    return child;
  }

  public List<Tile[]> getActions() {
    List<Tile[]> actions = new ArrayList<>();

    for (Tile queen : this.getQueenPositions()) {
      board2DArray[queen.row][queen.col] = 0;
      for (Tile move : this.getPossibleMoves(queen)) {
        for (Tile arrow : this.getPossibleMoves(move)) {
          actions.add(new Tile[] { queen.clone(), move.clone(), arrow.clone() }); // [oldPos, newPos, arrowPos]
        }
      }
      board2DArray[queen.row][queen.col] = queen.type;
    }

    return actions;
  }
  
  public GameState getMostVisited() {
	  return Collections.max(child, Comparator.comparing(GameState::getNumVisited));
  }
  public int getNumVisited() {
	  return numVisits;
  }

  private List<Tile> getPossibleMoves(Tile initPosition) {
    List<Tile> moves = new ArrayList<>();

    int[] dx = { -1, 1, 0, 0, -1, -1, 1, 1 };
    int[] dy = { 0, 0, -1, 1, -1, 1, -1, 1 };

    for (int i = 0; i < dx.length; i++) {
      int x = initPosition.row + dx[i];
      int y = initPosition.col + dy[i];

      while (GameState.isValid(x, y)) {
        if (this.board2DArray[x][y] == 0) {
          moves.add(new Tile(x, y, Tile.MOVES));
        } else {
          break;
        }
        x += dx[i];
        y += dy[i];
      }
    }

    return moves;
  }

  private static boolean isValid(int x, int y) {
    return x >= 0 && x < 10 && y >= 0 && y < 10;
  }

  public List<GameState> getUnexploredChild() {
    List<GameState> unexploredStates = new ArrayList<GameState>();
    for (GameState children : child) {
      if (children.numVisits == 0)
        unexploredStates.add(children);
    }
    return unexploredStates;
  }

  // Still error, have to update comparing method

  // probably need to delete this
  public GameState getRandomChild(Random rand) {
    return child.get(rand.nextInt(child.size()));
  }

  public void addChild(GameState newState) {
    child.add(newState);
  }

  public boolean isFullyExpanded(GameState currState) {

    if (currState.child.isEmpty()) {
      return false;
    }

    for (GameState child : currState.child) {
      if (child.numVisits == 0) {
        return false;
      }
    }

    return true;
  }

  public int getWinner() {
    return winner;
  }

  /*
   * return the expected outcome from the given state given by the heur function:
   * 1: winning state for us
   * -1: losing state for us
   */
  public int getStateOutcome() {
    if (this.winner == myID) {
      return 1;
    } else {
      return -1;
    }
  }

}
