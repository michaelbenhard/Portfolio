package ubc.cosc322.states;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class State {
  // let's keep all these to private. access them using the getters/setters
  private int whosTurn; // who can make move in this state
  private int[][] board;
  private int[][] blackPositions;
  private int[][] whitePositions;

  private Move prevMove; // keeps track the previous move made to reach this state
  private List<Move> availableMoves;

  /**
   * Creates new instance of the State object with the initial board at the start
   * of the game.
   * 
   * THIS IS A TEST CONSTRUCTOR, DON'T USE IN COSC322Test
   */
  public State() {
    this.whosTurn = Constant.BLACK;
    this.board = new int[][] {
        { 0, 0, 0, 2, 0, 0, 2, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 },
    };
    this.blackPositions = new int[][] {
        new int[] { 0, 3 },
        new int[] { 0, 6 },
        new int[] { 3, 0 },
        new int[] { 3, 9 },
    };
    this.whitePositions = new int[][] {
        new int[] { 9, 3 },
        new int[] { 9, 6 },
        new int[] { 6, 0 },
        new int[] { 6, 9 },
    };
    this.prevMove = null;
    this.availableMoves = new ArrayList<>();
    updateAvailableMoves();
  }

  public State(int whosTurn, int[][] board, int[][] blackPositions, int[][] whitePositions) {
    this.whosTurn = whosTurn;
    this.board = new int[10][];
    for (int i = 0; i < board.length; i++) {
      this.board[i] = Arrays.copyOf(board[i], board[i].length);
    }
    this.blackPositions = new int[4][];
    for (int i = 0; i < blackPositions.length; i++) {
      this.blackPositions[i] = Arrays.copyOf(blackPositions[i], blackPositions[i].length);
    }
    this.whitePositions = new int[4][];
    for (int i = 0; i < whitePositions.length; i++) {
      this.whitePositions[i] = Arrays.copyOf(whitePositions[i], whitePositions[i].length);
    }
    this.prevMove = null;
    this.availableMoves = new ArrayList<>();
    updateAvailableMoves();
  }

  /**
   * this is a copy constructor for the State class
   */
  public State(State stateToCopy) {
    // Copy the board
    this.board = new int[stateToCopy.board.length][];
    for (int i = 0; i < stateToCopy.board.length; i++) {
      this.board[i] = Arrays.copyOf(stateToCopy.board[i], stateToCopy.board[i].length);
    }

    // Copy the other variables
    this.whosTurn = stateToCopy.whosTurn;
    if (this.prevMove != null)
      this.prevMove = stateToCopy.prevMove.copy();
    else
      this.prevMove = null;
    this.blackPositions = Arrays.copyOf(stateToCopy.blackPositions, stateToCopy.blackPositions.length);
    for (int i = 0; i < stateToCopy.blackPositions.length; i++) {
      this.blackPositions[i] = Arrays.copyOf(stateToCopy.blackPositions[i], stateToCopy.blackPositions[i].length);
    }
    this.whitePositions = Arrays.copyOf(stateToCopy.whitePositions, stateToCopy.whitePositions.length);
    for (int i = 0; i < stateToCopy.whitePositions.length; i++) {
      this.whitePositions[i] = Arrays.copyOf(stateToCopy.whitePositions[i], stateToCopy.whitePositions[i].length);
    }
    this.availableMoves = new ArrayList<>();
    for (Move move : stateToCopy.availableMoves) {
      this.availableMoves.add(move.copy());
    }
  }

  /**
   * @return a deep copy of the State object.
   */
  public State copy() {
    return new State(this);
  }

  public void makeMove(Move move) {
    // Update the board
    board[move.oldPos[0]][move.oldPos[1]] = 0;
    board[move.newPos[0]][move.newPos[1]] = whosTurn;
    board[move.arrowPos[0]][move.arrowPos[1]] = Constant.ARROW;

    // Update the positions of the player who made the move
    if (whosTurn == Constant.BLACK) {
      blackPositions[move.index][0] = move.newPos[0];
      blackPositions[move.index][1] = move.newPos[1];
    } else {
      whitePositions[move.index][0] = move.newPos[0];
      whitePositions[move.index][1] = move.newPos[1];
    }

    // Switch the turn to the other player
    whosTurn = (whosTurn == Constant.BLACK) ? Constant.WHITE : Constant.BLACK;

    // Store the move in prevMove
    prevMove = move;

    // Update the available moves as board state is updated
    updateAvailableMoves();
  }

  /**
   * update moves of the current state.
   */
  public void updateAvailableMoves() {
    this.availableMoves.clear();
    for (int i = 0; i < 4; i++) { // add moves for all 4 queens
      this.availableMoves.addAll(getPossibleMoves(i));
    }
  }

  /**
   * Creates a List of Moves from the given parameters.
   * 
   * @param player the player to be moved (0-indexed)
   * @return a List<Move> object representing the available Moves from the
   *         initPosition
   */
  public List<Move> getPossibleMoves(int player) {
    int[] initPosition = whosTurn == Constant.BLACK ? blackPositions[player] : whitePositions[player];

    List<Move> moves = new ArrayList<>();

    int[] dx = { -1, 1, 0, 0, -1, -1, 1, 1 };
    int[] dy = { 0, 0, -1, 1, -1, 1, -1, 1 };

    // Check all directions from the amazon's current position
    for (int i = 0; i < dx.length; i++) {
      int x = initPosition[0] + dx[i];
      int y = initPosition[1] + dy[i];
      while (State.isValid(x, y)) {
        if (board[x][y] != 0) {
          break; // Stop searching in this direction if the cell is blocked
        }

        // If the cell is empty, create a new move for each possible arrow position
        for (int j = 0; j < dx.length; j++) {

          int arrowX = x + dx[j];
          int arrowY = y + dy[j];

          // update board temporarily
          board[initPosition[0]][initPosition[1]] = Constant.EMPTY;

          while (State.isValid(arrowX, arrowY)) {
            if (board[arrowX][arrowY] != 0) {
              break; // Stop searching in this direction if the cell is blocked
            }
            int[] newAmazonPos = { x, y };
            int[] newArrowPos = { arrowX, arrowY };
            //may need code to check if this arrow position traps own queen before adding
            //
            //
            //
            //
            moves.add(new Move(initPosition, newAmazonPos, newArrowPos, player));
            arrowX += dx[j];
            arrowY += dy[j];
          }

          // restore board
          board[initPosition[0]][initPosition[1]] = whosTurn;
        }

        // Update the position and continue in the same direction
        x += dx[i];
        y += dy[i];
      }
    }

    return moves;
  }

  /**
   * SHOULD ONLY BE CALLED IF STATE IS TERMINAL.
   * 
   * @return BLACK if current turn is WHITE and vice versa.
   */
  public int getWinner() {
    return whosTurn == Constant.BLACK ? Constant.WHITE : Constant.BLACK;
  }

  /**
   * @return true if it is the end of the game. ie. whosTurn does not have any
   *         available move.
   */
  public boolean isTerminal() {
    return this.getAvailableMoves().isEmpty();
  }

  public int[][] getBoard() {
    return this.board;
  }

  public void setBoard(int[][] board) {
    this.board = board;
  }

  public int getWhosTurn() {
    return this.whosTurn;
  }

  public void setWhosTurn(int whosTurn) {
    this.whosTurn = whosTurn;
  }

  public Move getPrevMove() {
    return this.prevMove;
  }

  public void setPrevMove(Move prevMove) {
    this.prevMove = prevMove;
  }

  public int[][] getBlackPositions() {
    return this.blackPositions;
  }

  public void setBlackPositions(int[][] blackPositions) {
    this.blackPositions = blackPositions;
  }

  public int[][] getWhitePositions() {
    return this.whitePositions;
  }

  public void setWhitePositions(int[][] whitePositions) {
    this.whitePositions = whitePositions;
  }

  public List<Move> getAvailableMoves() {
    return this.availableMoves;
  }

  public void setAvailableMoves(List<Move> availableMoves) {
    this.availableMoves = availableMoves;
  }

  /**
   * Creates a List of Moves from the given parameters.
   * 
   * @param x row
   * @param y col
   * @return true if the given position is within the 10x10 grid.
   */
  private static boolean isValid(int x, int y) {
    return x >= 0 && x < 10 && y >= 0 && y < 10;
  }

  public void printBoard() {
    for (int[] r : board)
      System.out.println(Arrays.toString(r));
  }

  @Override
  public String toString() {
    return "{" +
        " whosTurn='" + getWhosTurn() + "'" +
        ", board='" + Arrays.toString(getBoard()) + "'" +
        ", blackPositions='" + Arrays.toString(getBlackPositions()) + "'" +
        ", whitePositions='" + Arrays.toString(getWhitePositions()) + "'" +
        ", prevMove='" + getPrevMove() + "'" +
        ", availableMoves='" + getAvailableMoves() + "'" +
        "}";
  }
}
