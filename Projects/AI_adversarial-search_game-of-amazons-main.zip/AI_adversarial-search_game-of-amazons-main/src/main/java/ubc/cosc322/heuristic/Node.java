package ubc.cosc322.heuristic;

import java.util.ArrayList;

public class Node {
	    private Node parent;
	    private ArrayList<Node> children;
	    private GameState state;
	    private int player;
	    private int numSimulations;
	    private int numWins;
	    private int numVisits;
	    
	    public Node(Node parent, GameState state, int whosTurn) {
	        this.parent = parent;
	        this.children = new ArrayList<Node>();
	        this.state = state;
	        this.player = whosTurn;
	        this.numSimulations = 0;
	        this.numWins = 0;
	        this.numVisits = 0;
	    }
	    
	    public Node getParent() {
	        return parent;
	    }
	    
	    public ArrayList<Node> getChildren() {
	        return children;
	    }
	    
	    public ArrayList<Node> getUnvisitedChildren() {
	        ArrayList<Node> unvisitedChildren = new ArrayList<Node>();
	        for (Node child : children) {
	            if (child.getNumSimulations() == 0) {
	                unvisitedChildren.add(child);
	            }
	        }
	        return unvisitedChildren;
	    }
	    
	    public GameState getState() {
	        return state;
	    }
	    
	    
	    public int getPlayer() {
	        return player;
	    }
	    
	    public int getNumVisits() {
	        return numVisits;
	    }
	    
	    public int getNumSimulations() {
	        return numSimulations;
	    }
	    
	    public int getNumWins() {
	        return numWins;
	    }
	    
	    public void addChild(Node child) {
	        children.add(child);
	    }
	    
	    public double getUCB1(int parentSimulations, double explorationParameter) {
	        double exploitationTerm = (double) numWins / numSimulations;
	        double explorationTerm = explorationParameter * Math.sqrt(Math.log(parentSimulations) / numSimulations);
	        return exploitationTerm + explorationTerm;
	    }
	    
	    
	    public void updateStats(int result) {
	        numSimulations++;
	        numWins += result;
	    }
	
}
