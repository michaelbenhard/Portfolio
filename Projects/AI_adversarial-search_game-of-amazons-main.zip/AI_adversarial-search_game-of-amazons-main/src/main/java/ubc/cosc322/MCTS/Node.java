package ubc.cosc322.MCTS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import ubc.cosc322.states.Constant;
import ubc.cosc322.states.Move;
import ubc.cosc322.states.State;

public class Node {
  private Node parent;
  private State state;
  private List<Node> children;
  private int visits;
  private int wins;

  public Node(State state) {
    this.state = state;
    this.parent = null;
    this.children = new ArrayList<>();
    this.visits = 0;
    this.wins = 0;
  }

  public boolean hasUnvisitedChild() throws Exception {
    return this.countVisitedChild() < children.size();
  }

  private int countVisitedChild() {
    int count = 0;
    for (Node child : children) {
      if (child.getVisits() > 0)
        count++;
    }
    return count;
  }

  // return the child with the highest number of visits
  public Node getBestChild() {
    Node bestChild = children.get(0);
    for (Node child : children) {
      if (child.visits > bestChild.visits) {
        bestChild = child;
      }
    }
    return bestChild;
  }

  // return the child with the highest UCB value
  public Node selectChild(double EXPLORATION_FACTOR) {
    Node selected = null;
    double bestScore = Double.MIN_VALUE;
    for (Node child : children) {
      if (child.getVisits() == 0)
        return child;
      double score = (child.getWins() / child.getVisits())
          + EXPLORATION_FACTOR * Math.sqrt(Math.log(visits) / child.getVisits()); // UCB value
      if (score > bestScore) {
        selected = child;
        bestScore = score;
      }
    }
    return selected;
  }

  public Move getUntriedMove() {
    List<Move> triedMoves = new ArrayList<>();
    for (Node child : children) {
      triedMoves.add(child.getState().getPrevMove());
    }
    List<Move> availableMoves = new ArrayList<>(state.getAvailableMoves());
    availableMoves.removeAll(triedMoves);
    if (availableMoves.isEmpty()) {
      return null;
    }
    return availableMoves.get(new Random().nextInt(availableMoves.size()));
  }

  public boolean isFullyExpanded() throws Exception {
    return children.size() >= state.getAvailableMoves().size();
  }

  public boolean isFullyExpandedCapped(int maxBranchingFactor) {
    return children.size() >= maxBranchingFactor;
  }

  public void update(int result) {
    visits++;
    wins += result;
  }

  public boolean isTerminal() {
    return state.isTerminal();
  }

  public Node getParent() {
    return parent;
  }

  public void setParent(Node parent) {
    this.parent = parent;
  }

  public void setState(State state) {
    this.state = state;
  }

  public void setChildren(List<Node> children) {
    this.children = children;
  }

  public void setVisits(int visits) {
    this.visits = visits;
  }

  public State getState() {
    return state;
  }

  public List<Node> getChildren() {
    return children;
  }

  public int getVisits() {
    return visits;
  }

  public int getWins() {
    return wins;
  }

  public void setWins(int wins) {
    this.wins = wins;
  }

  public void incrementVisits() {
    visits++;
  }

  public void addChild(Node child) {
    children.add(child);
    child.setParent(this);
  }

  public void expand(int maxChildren) throws Exception {
    // Only expand for the player whose turn it is in this node
    int player = state.getWhosTurn();
    List<Move> allMoves = state.getAvailableMoves();
    List<Move> movesCloserToQueen = new ArrayList<>();

    // Find moves that move an Amazon closer to the enemy queen
    int[][] playerPositions = player == Constant.BLACK ? state.getBlackPositions() : state.getWhitePositions();
    int[][] enemyPositions = player == Constant.BLACK ? state.getWhitePositions() : state.getBlackPositions();
    int enemyQueenRow = enemyPositions[0][0];
    int enemyQueenCol = enemyPositions[0][1];
    for (Move move : allMoves) {
      double distance = Math
          .sqrt(Math.pow(enemyQueenRow - move.newPos[0], 2) + Math.pow(enemyQueenCol - move.newPos[1], 2));
      if (distance < Math.sqrt(
          Math.pow(enemyQueenRow - playerPositions[0][0], 2) + Math.pow(enemyQueenCol - playerPositions[0][1], 2))) {
        movesCloserToQueen.add(move);
      }
    }

    // Randomly select a subset of moves to expand child nodes for
    int numMoves = movesCloserToQueen.size();
    int numChildren = Math.min(numMoves, maxChildren);
    List<Move> selectedMoves = new ArrayList<>();
    Random rand = new Random();
    while (selectedMoves.size() < numChildren && movesCloserToQueen.size() > 0) {
      int index = rand.nextInt(movesCloserToQueen.size());
      Move move = movesCloserToQueen.get(index);
      selectedMoves.add(move);
      movesCloserToQueen.remove(index);
    }

    // handle if movesCloserToQueen.size() == 0 before selectedMoves.size() <
    // maxChildren;
    while (selectedMoves.size() < maxChildren) {
      Move move = getUntriedMove();
      if (move != null)
        selectedMoves.add(move);
      else
        break;
      // else no more node to expand
    }

    // Generate child nodes for selected moves
    for (Move move : selectedMoves) {
      State childState = state.copy();
      childState.makeMove(move);
      Node childNode = new Node(childState);
      this.addChild(childNode);
    }
  }

  public Node getRandomChild() {
    return this.children.get(new Random().nextInt(this.children.size()));
  }
}
