
package ubc.cosc322;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import sfs2x.client.entities.Room;
import ubc.cosc322.MCTS.MCTS;
import ubc.cosc322.heuristic.GameState;
import ubc.cosc322.heuristic.MonteCarloTreeSearch;
import ubc.cosc322.heuristic.Tile;
import ubc.cosc322.states.Constant;
import ubc.cosc322.states.Move;
import ubc.cosc322.states.State;
import ygraph.ai.smartfox.games.BaseGameGUI;
import ygraph.ai.smartfox.games.GameClient;
import ygraph.ai.smartfox.games.GameMessage;
import ygraph.ai.smartfox.games.GamePlayer;
import ygraph.ai.smartfox.games.amazons.AmazonsGameMessage;
import ygraph.ai.smartfox.games.amazons.HumanPlayer;

/**
 * An example illustrating how to implement a GamePlayer
 * 
 * @author Yong Gao (yong.gao@ubc.ca)
 *         Jan 5, 2021
 *
 */
public class COSC322Test extends GamePlayer {
	final static int MAX_TIMEOUT = 10;
	final int ARROW = 3;
	final int BLACK = 2;
	final int WHITE = 1;
	final int EMPTY = 0;

	private GameClient gameClient = null;
	private BaseGameGUI gamegui = null;

	private String userName = null;
	private String passwd = null;

	private int turnCount;
	private int opponentID;
	private int myID;

	private int[][] localBoard = {
			{ 0, 0, 0, 2, 0, 0, 2, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 },
	};
	private int[][] blackQueens;
	private int[][] whiteQueens;

	// initialize local variables
	private void initGame(Map<String, Object> msgDetails) {
		turnCount = 0;
		this.blackQueens = new int[][] {
				new int[] { 0, 3 },
				new int[] { 0, 6 },
				new int[] { 3, 0 },
				new int[] { 3, 9 },
		};
		this.whiteQueens = new int[][] {
				new int[] { 9, 3 },
				new int[] { 9, 6 },
				new int[] { 6, 0 },
				new int[] { 6, 9 },
		};

		if (((String) msgDetails.get(AmazonsGameMessage.PLAYER_BLACK)).equals(this.userName)) {
			myID = BLACK;
			opponentID = WHITE;
		} else if (((String) msgDetails.get(AmazonsGameMessage.PLAYER_WHITE)).equals(this.userName)) {
			myID = WHITE;
			opponentID = BLACK;
		} else {
			myID = opponentID = -1; // spectating
		}

		localBoard = new int[][] {
				{ 0, 0, 0, 2, 0, 0, 2, 0, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 },
		};
	}

	/**
	 * The main method
	 * 
	 * @param args for name and passwd (current, any string would work)
	 */
	public static void main(String[] args) {
		COSC322Test player = new COSC322Test(args[0], args[1]);
//		 HumanPlayer player = new HumanPlayer();

		if (player.getGameGUI() == null) {
			player.Go();
		} else {
			BaseGameGUI.sys_setup();
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					player.Go();
				}
			});
		}
	}

	/**
	 * Any name and passwd
	 * 
	 * @param userName
	 * @param passwd
	 */
	public COSC322Test(String userName, String passwd) {
		this.userName = userName;
		this.passwd = passwd;

		// To make a GUI-based player, create an instance of BaseGameGUI
		// and implement the method getGameGUI() accordingly
		this.gamegui = new BaseGameGUI(this);
	}

	@Override
	public void onLogin() {
		System.out.println("Congratualations!!! "
				+ "I am called because the server indicated that the login is successfully");
		System.out.println("The next step is to find a room and join it: "
				+ "the gameClient instance created in my constructor knows how!");

		this.userName = gameClient.getUserName();

		List<Room> rooms = this.gameClient.getRoomList();
		for (Room room : rooms) {
			System.out.println(room);
		}
		this.gameClient.joinRoom(rooms.get(0).getName());

		if (gamegui != null) {
			gamegui.setRoomInformation(gameClient.getRoomList());
		}

	}

	@Override
	public boolean handleGameMessage(String messageType, Map<String, Object> msgDetails) {
		// This method will be called by the GameClient when it receives a game-related
		// message
		// from the server.

		// For a detailed description of the message types and format,
		// see the method GamePlayer.handleGameMessage() in the game-client-api
		// document.
		System.out.println("MESSAGE TYPE: " + messageType);
		System.out.println("MESSAGE DETAILS: " + msgDetails);

		switch (messageType) {
			case GameMessage.GAME_ACTION_START:
				// update local Board
				initGame(msgDetails);
				if (whosTurn() == myID) {
					Move bestMove = findBestMove();
					this.gameClient.sendMoveMessage(moveToMsgdetails(bestMove));
					updateLocalState(bestMove);
					this.gamegui.updateGameState(moveToMsgdetails(bestMove));
					printLocalBoard();
					turnCount++;
				}
				break;
			case GameMessage.GAME_STATE_BOARD:
				this.gamegui.setGameState((ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.GAME_STATE));
				break;
			case GameMessage.GAME_ACTION_MOVE:
				this.gamegui.updateGameState(msgDetails);
				// Code for receive move
				// ArrayList<ArrayList<Integer>> move = receiveMove(msgDetails);
				// validateMove(move.get(0),move.get(1),move.get(2));
				validateMove((ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_CURR),
						(ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_NEXT),
						(ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.ARROW_POS));
				this.updateLocalState(msgDetails);
				printLocalBoard();

				// TODO: THIS IS BROKEN
				// check if game reached terminal state
				// if (isTerminalState()) {
				// System.out.println("GAME ENDED: WINNER = " + idToColor((whosTurn() % 2) +
				// 1));
				// break;
				// }
				turnCount++;

				if (whosTurn() == myID) {
					Move bestMove = findBestMove();
					if (bestMove == null) { // game ended
						System.out.println("GAME ENDED: WINNER = " + idToColor((whosTurn() % 2) + 1));
						break;
					}
					this.gameClient.sendMoveMessage(moveToMsgdetails(bestMove));
					updateLocalState(bestMove);
					this.gamegui.updateGameState(moveToMsgdetails(bestMove));
					System.out.println("BEST MOVE: " + bestMove);
					turnCount++;
				} else {
					System.out.println("whosTurn != myID on receiveMessage");
				}

				// sendMessageToServer(bestMove);
				// this.gameClient.sendMoveMessage(null, null, null); ignore
				printLocalBoard();
				System.out.println("blackQueens");
				for (int[] i : blackQueens)
					System.out.println(Arrays.toString(i));
				System.out.println("whiteQueens");
				for (int[] i : whiteQueens)
					System.out.println(Arrays.toString(i));
				break;
			default:
				break;
		}

		return true;
	}

	private Move findBestMove() {
		MCTS tree = new MCTS(new State(myID, localBoard, blackQueens, whiteQueens), myID);

		final ExecutorService executor = Executors.newSingleThreadExecutor();
		final Future<Object> future = executor.submit(() -> {
			tree.runSearch();
			return "ended runSearch()";
		});

		try {
			future.get(MAX_TIMEOUT, TimeUnit.SECONDS);
		} catch (TimeoutException e) {
			future.cancel(true);
			System.out.println("timeout reached!! sending bestMove");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return tree.getBestMove();
	}

	private Map<String, Object> moveToMsgdetails(Move move) {
		Map<String, Object> msg = new HashMap<>();
		msg.put(AmazonsGameMessage.QUEEN_POS_CURR,
				new ArrayList<>(Arrays.asList(10 - move.oldPos[0], move.oldPos[1] + 1)));
		msg.put(AmazonsGameMessage.QUEEN_POS_NEXT,
				new ArrayList<>(Arrays.asList(10 - move.newPos[0], move.newPos[1] + 1)));
		msg.put(AmazonsGameMessage.ARROW_POS,
				new ArrayList<>(Arrays.asList(10 - move.arrowPos[0], move.arrowPos[1] + 1)));
		return msg;
	}

	@Override
	public String userName() {
		return userName;
	}

	@Override
	public GameClient getGameClient() {
		return this.gameClient;
	}

	@Override
	public BaseGameGUI getGameGUI() {
		return this.gamegui;
	}

	@Override
	public void connect() {
		gameClient = new GameClient(userName, passwd, this);
	}

	private void updateLocalState(Move move) {
		this.updateLocalState(move.oldPos, move.newPos, move.arrowPos);
	}

	private void updateLocalState(Map<String, Object> msgDetails) {
		// parse msgDetails into array
		ArrayList<Integer> oldPosList = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_CURR);
		ArrayList<Integer> newPosList = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_NEXT);
		ArrayList<Integer> arrowPosList = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.ARROW_POS);
		int[] oldPos = new int[] { 10 - oldPosList.get(0), oldPosList.get(1) - 1 };
		int[] newPos = new int[] { 10 - newPosList.get(0), newPosList.get(1) - 1 };
		int[] arrowPos = new int[] { 10 - arrowPosList.get(0), arrowPosList.get(1) - 1 };
		this.updateLocalState(oldPos, newPos, arrowPos);
	}

	private void updateLocalState(int[] oldPos, int[] newPos, int[] arrowPos) {
		// update queens' positions
		// update queens' positions
		for (int[] q : whosTurn() == Constant.BLACK ? blackQueens : whiteQueens) {
			if (q[0] == oldPos[0] && q[1] == oldPos[1]) {
				q[0] = newPos[0];
				q[1] = newPos[1];
				break;
			}
		}
		System.out.println("update local board: oldPos");
		System.out.println(Arrays.toString(oldPos));
		System.out.println(localBoard[oldPos[0]][oldPos[0]]);
		// IMPLEMENT UPDATE LOCAL BOARD
		localBoard[oldPos[0]][oldPos[1]] = EMPTY;
		localBoard[newPos[0]][newPos[1]] = whosTurn();
		localBoard[arrowPos[0]][arrowPos[1]] = ARROW;
	}

	private int whosTurn() {
		if (turnCount % 2 == 0)
			return BLACK;
		else
			return WHITE;
	}

	public boolean validateMove(ArrayList<Integer> currPos, ArrayList<Integer> newPos, ArrayList<Integer> arrowPos) {
		// TODO: check if queen jumps over arrowed Tile

		// check turn
		if (whosTurn() != opponentID) {
			System.out.println("IT'S NOT " + idToColor(opponentID) + "'s TURN!!!!!!!!!!!, ON TURN = " + (turnCount + 1));
		}

		boolean valid = true;
		// CHECK IF PLAYER IS MOVING THEIR PIECE
		if (localBoard[10 - currPos.get(0)][currPos.get(1) - 1] != whosTurn()) {
			System.out.println("ILLEGAL MOVE: " + idToColor(whosTurn()) + " IS MOVING THE "
					+ (localBoard[10 - currPos.get(0)][10 - currPos.get(1)]) + "'s PIECE");
			valid = false;
		}

		// CHECK IF THE NEWPOS AND ARROWPOS IS EMPTY
		if (localBoard[10 - newPos.get(0)][newPos.get(1) - 1] != EMPTY) {
			System.out.println("ILLEGAL MOVE: PLAYER IS MOVING TO A NON-EMPTY SPOT");
			valid = false;
		}

		// CHECK IF THE NEWPOS AND ARROWPOS IS EMPTY
		if ((localBoard[10 - arrowPos.get(0)][arrowPos.get(1) - 1] != EMPTY) && !(localBoard[10 - currPos.get(0)][currPos.get(1)-1] == localBoard[10 - arrowPos.get(0)][arrowPos.get(1)-1])) {
			System.out.println("ILLEGAL MOVE: PLAYER IS SHOOTING ARROW TO A NON-EMPTY SPOT");
			valid = false;
		}
		if (valid)
			System.out.println("Opponent made a valid move");
		// check if the move itself is valid, queen and arrow
		return valid && isValidMove(currPos, newPos) && isValidMove(newPos, arrowPos);
	}

	private boolean isTerminalState() {
		// TODO: test isTerminalState()
		int[][] queens = null;
		if (whosTurn() == BLACK) {
			queens = blackQueens;
		} else if (whosTurn() == WHITE) {
			queens = whiteQueens;
		}

		for (int[] queen : queens) {
			// check if any of the 8 directions is available, from north then clockwise
			if ((queen[0] - 1 < 0 || localBoard[queen[0] - 1][queen[1]] != 0) // check north, then clockwise
					&& ((queen[0] - 1 < 0 || queen[1] + 1 >= 10) || localBoard[queen[0] - 1][queen[1] + 1] != 0)
					&& (queen[1] + 1 >= 10 || localBoard[queen[0]][queen[1] + 1] != 0)
					&& ((queen[0] + 1 >= 10 || queen[1] + 1 >= 10) || localBoard[queen[0] + 1][queen[1] + 1] != 0)
					&& (queen[0] + 1 >= 10 || localBoard[queen[0] + 1][queen[1]] != 0)
					&& ((queen[0] + 1 >= 10 || queen[1] - 1 < 0) || localBoard[queen[0] + 1][queen[1] - 1] != 0)
					&& (queen[1] - 1 < 0 || localBoard[queen[0]][queen[1] - 1] != 0)
					&& ((queen[0] - 1 < 0 || queen[1] - 1 < 0) || localBoard[queen[0] - 1][queen[1] - 1] != 0)) {
				return true;
			}
		}

		return false;
	}

	// check validity of move
	public boolean isValidMove(ArrayList<Integer> currPos, ArrayList<Integer> newPos) {

		// check if new position is equal to current position for queen
		if (currPos.get(0) == newPos.get(0) && currPos.get(1) == newPos.get(1)) {
			System.out.println("ILLEGAL MOVE: NEW POSITION IS EQUAL TO CURRENT POSITION");
			return false;
		}

		// check out of bound for queen and arrow
		if (newPos.get(0) < 1 || newPos.get(0) > 10 || newPos.get(1) < 1 || newPos.get(1) > 10) {
			System.out.println("ILLEGAL MOVE: NEW POSITION IS OUT OF BOUNDS");
			return false;
		}

		// Change in x-value for gradient
		double changeX = Math.abs(newPos.get(1) - currPos.get(1));
		// Change in y-value for gradient
		double changeY = Math.abs(newPos.get(0) - currPos.get(0));

		if (changeX == 0) { // check for horizontal move, invalid otherwise
			return true;
		}

		if (changeY == 0) { // check for vertical move, invalid otherwise
			return true;
		}

		double gradient = changeY / changeX;

		// check gradient conditions
		if (gradient != 1.0) {
			System.out.println("ILLEGAL MOVE: QUEEN/ARROW SHOULD MOVE STRAIGHT OR DIAGONAL");
			return false;
		}

		System.out.println("Searched for a valid move");
		return true;
	}

	private void printLocalBoard() {
		System.out.println("local board: ");
		for (int[] i : localBoard) {
			System.out.println(Arrays.toString(i));

		}
	}

	public static void printBoard(GameState state) {
		System.out.println("state board: ");
		for (int[] i : state.board2DArray) {
			System.out.println(Arrays.toString(i));

		}
	}

	private String idToColor(int id) {
		return id == BLACK ? "black" : "white";
	}

	// send move to game server
	public void sendMove(ArrayList<Integer> posCurr, ArrayList<Integer> nextPos, ArrayList<Integer> arrowPos) {
		this.getGameClient().sendMoveMessage(posCurr, nextPos, arrowPos);
	}

	// receive move from game server
	public ArrayList<ArrayList<Integer>> receiveMove(Map<String, Object> msgDetails) {
		ArrayList<ArrayList<Integer>> arrList = new ArrayList<ArrayList<Integer>>(3);
		ArrayList<Integer> currPos = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_CURR);
		ArrayList<Integer> newPos = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.QUEEN_POS_NEXT);
		ArrayList<Integer> arrPos = (ArrayList<Integer>) msgDetails.get(AmazonsGameMessage.ARROW_POS);
		arrList.add(currPos);
		arrList.add(newPos);
		arrList.add(arrPos);
		return arrList;
	}

}// end of class
