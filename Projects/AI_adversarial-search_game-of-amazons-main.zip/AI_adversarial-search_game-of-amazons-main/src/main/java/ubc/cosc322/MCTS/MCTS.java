package ubc.cosc322.MCTS;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import ubc.cosc322.states.Move;
import ubc.cosc322.states.State;

public class MCTS {
  private static final int NUM_SIMULATIONS = 3000;
  // private static final double EXPLORATION_FACTOR = 0;
  private static final double EXPLORATION_FACTOR = Math.sqrt(2);
  private static final int MAX_BRANCHING_FACTOR = 50; // TODO: TUNE THIS PARAMETER
  private static final int EARLY_GAME_BOUNDARY = 1000;// TODO: TUNE THIS PARAMETER

  private Node rootNode;
  private int ourColor;

  public MCTS(State initialState, int ourColor) {
    rootNode = new Node(initialState);
    this.ourColor = ourColor;
  }

  public void runSearch() throws Exception {
    if (rootNode.isTerminal()) {
      System.out.println("ROOT NODE IS TERMINAL");
      System.out.println("WINNER: " + rootNode.getState().getWinner());
      return;
    }
    int i = 0;
    while (true) {
      Node node = rootNode;

      // for debugging
      // if (i++ % 1000 == 0) {
      // System.out.println("iteration: " + i);
      // System.out.println("node children: " + node.getChildren().size());
      // }

      // for debugging
      // if (i == 8) {
      // System.out.println();
      // }

      // Selection
      Node selected;
      while (!node.hasUnvisitedChild() && (selected = node.selectChild(EXPLORATION_FACTOR)) != null) {
        node = selected;
        // state.makeMove(node.getState().getPrevMove());
      }

      // Expansion is capped for late game to prioritize depth than width of tree
      boolean isFullyExpanded;
      if (isEarlyGame(rootNode)) { // expand more often
        isFullyExpanded = node.isFullyExpanded(); // may need to cap this as well
      } else { // expand less often
        isFullyExpanded = node.isFullyExpandedCapped(MAX_BRANCHING_FACTOR);
      }
      if (!isFullyExpanded && !node.isTerminal()) {
        node.expand(1);
        node = node.getRandomChild();
        // state.makeMove(node.getState().getPrevMove());
      }

      // Simulation
      int winner = simulate(node);

      // Backpropagation
      while (node != null) {
        node.update(winner);
        node = node.getParent();
      }
    }
  }

  private int simulate(Node node) {
    State state = node.getState().copy();
    Random rand = new Random();
    while (!state.isTerminal()) {
      List<Move> moves = state.getAvailableMoves();
      Collections.shuffle(moves, rand);
      state.makeMove(moves.get(0));
    }
    return state.getWinner() == ourColor ? 1 : -1;
  }

  public Move getBestMove() {
    if (rootNode.isTerminal()) {
      System.out.println("ROOT NODE IS TERMINAL");
      System.out.println("WINNER: " + rootNode.getState().getWinner());
      return null;
    }
    return rootNode.getBestChild().getState().getPrevMove();
  }

  public Node getBestChildNode() {
    return rootNode.getBestChild();
  }

  // returns true if the availableMoves.size > EARLY_GAME_BOUNDARY, ie. consider
  // this as early game
  private boolean isEarlyGame(Node node) {
    return node.getState().getAvailableMoves().size() > EARLY_GAME_BOUNDARY;
  }

  public Node getRootNode() {
    return rootNode;
  }

  public static void setTimeout(Runnable runnable, int delay) {
    new Thread(() -> {
      try {
        Thread.sleep(delay);
        runnable.run();
      } catch (Exception e) {
        System.err.println(e);
      }
    }).start();
  }
}
