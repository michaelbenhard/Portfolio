package ubc.cosc322.states;

import java.util.Arrays;

public class Move implements Cloneable {
  public int[] oldPos;
  public int[] newPos;
  public int[] arrowPos;
  public int index; // idx of queen that made the move

  /**
   * Creates a Move
   * 
   * @param oldPos   old queen position
   * @param newPos   new queen position
   * @param arrowPos arrow position
   * @param idx      the identifier of the queen being moved
   */
  public Move(int[] oldPos, int[] newPos, int[] arrowPos, int idx) {
    this.oldPos = oldPos.clone();
    this.newPos = newPos.clone();
    this.arrowPos = arrowPos.clone();
    this.index = idx;
  }

  /**
   * Creates a copy of Move
   * 
   * @return a copy of Move object
   */
  protected Move copy() {
    return new Move(oldPos, newPos, arrowPos, index);
  }

  @Override
  public String toString() {
    return "{" +
        " oldPos='" + Arrays.toString(this.oldPos) + "'" +
        ", newPos='" + Arrays.toString(this.newPos) + "'" +
        ", arrowPos='" + Arrays.toString(this.arrowPos) + "'" +
        ", index='" + this.index + "'" +
        "}";
  }

}
