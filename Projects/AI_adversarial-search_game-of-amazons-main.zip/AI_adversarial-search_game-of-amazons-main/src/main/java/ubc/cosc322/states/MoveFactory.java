package ubc.cosc322.states;

public class MoveFactory {

}
