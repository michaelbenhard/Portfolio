package ubc.cosc322;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ubc.cosc322.heuristic.GameState;
import ubc.cosc322.heuristic.MonteCarloTreeSearch;
import ubc.cosc322.heuristic.Tile;

public class test {
	public static void main(String[] args) throws CloneNotSupportedException {

		// COSC322Test player = new COSC322Test(args[0], args[1]);

//		int[][] board2DArray = new int[][] {
//				{ 0, 0, 0, 2, 0, 0, 2, 0, 0, 0 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
//				{ 0, 0, 0, 1, 0, 0, 1, 0, 0, 0 },
//		};
		int[][] board2DArray = new int[][] {
			{ 3, 3, 3, 2, 3, 3, 2, 3, 3, 3 },
			{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
			{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
			{ 2, 0, 0, 0, 0, 0, 0, 0, 0, 2 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
			{3, 3, 3, 3, 3, 3, 3, 3, 3, 3  },
			{3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
			{3, 3, 3, 1, 3, 3, 1, 3, 3, 3 },
	};
		int[][] board2 = new int[][] {
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 0, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 0, 3, 3, 3 },
				{ 0, 0, 0, 3, 0, 0, 0, 3, 3, 3 },
				{ 0, 0, 0, 3, 3, 3, 1, 2, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
				{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
		};
		List<Tile> white = new ArrayList<>(Arrays.asList(new Tile(6, 0, 1), new Tile (6,9,1)));
		List<Tile> black = new ArrayList<>(Arrays.asList(new Tile(3, 0, 2), new Tile (3,9, 2)));

		GameState root1 = new GameState(Tile.BLACK, 10, Tile.BLACK);
		GameState root = new GameState(board2DArray, black, white, 2, null);

		// for (Tile[] t : root.getActions()) {
		// System.out.println(Arrays.toString(t));
		// }
		MonteCarloTreeSearch mcts = new MonteCarloTreeSearch(root, 10);
		GameState bestMoveState = mcts.findBestMove();
		System.out.println("root");
		COSC322Test.printBoard(root);
		System.out.println("bestState");
		COSC322Test.printBoard(bestMoveState);
		System.out.println(bestMoveState);
		System.out.println(bestMoveState.getParent().child.size());
	}

}