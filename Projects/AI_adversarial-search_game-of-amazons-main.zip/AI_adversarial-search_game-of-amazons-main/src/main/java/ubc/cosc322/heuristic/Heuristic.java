package ubc.cosc322.heuristic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Queue;

public class Heuristic {
	HashMap<Integer, Integer> ownedBy;
	GameState gameState;
	int[][] gameBoard;
	int[][] qHeurBlack;
	int[][] qHeurWhite;
	int[][] kHeurBlack;
	int[][] kHeurWhite;

	public Heuristic(int[][] gameBoard) {
		this.gameBoard = gameBoard;
		int[][] qHeurBlack = new int[10][10];
		int[][] qHeurWhite = new int[10][10];
		int[][] kHeurBlack = new int[10][10];
		int[][] kHeurWhite = new int[10][10];
		ownedBy = new HashMap<>();
		ownedBy.put(Tile.BLACK, 0);
		ownedBy.put(Tile.WHITE, 0);

		this.compute();
		System.out.println(ownedBy);
	}
	
	public int whosWinning(int myID) {
		if(ownedBy.get(myID) - ownedBy.get((myID%2) + 1) > 0)
			return myID;
		else
			return (myID%2) + 1;
	}

	public int getOwnedByWhite() {
		return ownedBy.get(Tile.WHITE);
	}

	public int getOwnedByBlack() {
		return ownedBy.get(Tile.BLACK);
	}

	private void compute() {
		minQueenHeur();
		minKingHeur();
	}

	public void minQueenHeur() {
		for (int r = 0; r < 10; r++) {
			for (int c = 0; c < 10; c++) {
				// if Tile is empty
				if (gameBoard[r][c] == 0)
					findNearestQueen(r, c);
			}
		}
	}

	private void findNearestQueen(int row, int col) {
		boolean[][] checked = new boolean[10][10];
		checked[row][col] = true;

		Queue<Tile> q = new LinkedList<>();
		q = addQueenMoves(q, row, col, checked);

		// System.out.println("" + row + col);
		// System.out.println(q);

		while (!q.isEmpty()) {
			Tile currentTile = q.poll();
			if (gameBoard[currentTile.row][currentTile.col] == Tile.BLACK
					|| gameBoard[currentTile.row][currentTile.col] == Tile.WHITE) {
				boolean contested = false;
				int opponent = (gameBoard[currentTile.row][currentTile.col] % 2) + 1;
				for (Tile t : q) {
					if (gameBoard[t.row][t.col] == opponent) {
						contested = true;
						break;
					}
				}
				if (!contested) {
					ownedBy.put(gameBoard[currentTile.row][currentTile.col],
							ownedBy.get(gameBoard[currentTile.row][currentTile.col]) + 1);
				}
				return;
			}
			checked[currentTile.row][currentTile.col] = true;
			if (gameBoard[currentTile.row][currentTile.col] == Tile.EMPTY)
				q = addQueenMoves(q, currentTile.row, currentTile.col, checked);
		}
	}

	// should compute heuristic for black white and final heur
	public int computeHeuristic() {
		return -1;
	}

	public static void minKingHeur() {

	}

	// add arg, int phase, add phaseNumber to
	public Queue<Tile> addQueenMoves(Queue<Tile> q, int curRow, int curCol, boolean[][] checked) {
		int r, c;
		// add moves to the right
		for (int i = 1; (c = curCol + i) < 10; i++) {
			Tile lData = new Tile(curRow, c);
			if (checked[curRow][c] == false) {
				q.add(lData);
			}
			if (gameBoard[curRow][c] != Tile.EMPTY) {
				break;
			}
		}

		// towards bottom right
		for (int i = 1; (r = curRow + i) < 10 && (c = curCol + i) < 10; i++) {
			Tile lData = new Tile(r, c);
			if (checked[r][c] == false) {
				q.add(lData);
			}
			if (gameBoard[r][c] != Tile.EMPTY) {
				break;
			}
		}

		// towards bottom
		for (int i = 1; (r = curRow + i) < 10; i++) {
			Tile lData = new Tile(r, curCol);
			if (checked[r][curCol] == false) {
				q.add(lData);
			}
			if (gameBoard[r][curCol] != Tile.EMPTY) {
				break;
			}
		}

		// towards bottom left
		for (int i = 1; (r = curRow + i) < 10 && (c = curCol - i) >= 0; i++) {
			Tile lData = new Tile(r, c);
			if (checked[r][c] == false) {
				q.add(lData);
			}
			if (gameBoard[r][c] != Tile.EMPTY) {
				break;
			}
		}

		// towards left
		for (int i = 1; (c = curCol - i) >= 0; i++) {
			Tile lData = new Tile(curRow, c);
			if (checked[curRow][c] == false) {
				q.add(lData);
			}
			if (gameBoard[curRow][c] != Tile.EMPTY) {
				break;
			}
		}

		// towards top left
		for (int i = 1; (r = curRow - i) >= 0 && (c = curCol - i) >= 0; i++) {
			Tile lData = new Tile(r, c);
			if (checked[r][c] == false) {
				q.add(lData);
			}
			if (gameBoard[r][c] != Tile.EMPTY) {
				break;
			}
		}

		// towards top
		for (int i = 1; (r = curRow - i) >= 0; i++) {
			Tile lData = new Tile(r, curCol);
			if (checked[r][curCol] == false) {
				q.add(lData);
			}
			if (gameBoard[r][curCol] != Tile.EMPTY) {
				break;
			}
		}

		// towards top right
		for (int i = 1; (r = curRow - i) >= 0 && (c = curCol + i) < 10; i++) {
			Tile lData = new Tile(r, c);
			if (checked[r][c] == false) {
				q.add(lData);
			}
			if (gameBoard[r][c] != Tile.EMPTY) {
				break;
			}
		}
		return q;
	}
}