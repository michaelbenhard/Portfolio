package ubc.cosc322.heuristic;

import java.util.Random;

import ubc.cosc322.COSC322Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MonteCarloTreeSearch {
	private GameState root;
	private int maxIterations;// TODO; change to time
	private Random rand;

	public MonteCarloTreeSearch(GameState root, int maxIterations) {
		this.root = root;
		this.maxIterations = maxIterations;
		this.rand = new Random();

	}

	// This where we get the best move for all queens
	public GameState findBestMove() {
		expand(root);
		for (int i = 0; i < maxIterations; i++) {
			GameState leaf = select(root);
			GameState terminalNode = null;
			if (leaf.numVisits == 0) {
				terminalNode = simulate(leaf);
			} else {
				leaf = expand(leaf);
				terminalNode = simulate(leaf);
			}
			COSC322Test.printBoard(terminalNode);
			System.out.println(terminalNode.whosTurn);
			System.out.println(terminalNode.blackQueens);
			System.out.println(terminalNode.whiteQueens);
			System.out.println(terminalNode.isTerminalNode());
			backpropagate(terminalNode, terminalNode.getStateOutcome());
			// System.out.println("Iteration number: " + (i + 1));
		}
		return root.getMostVisited();
	}

	// if numvisit=0, simulate till terminal node
	private GameState select(GameState state) {

		while (state.child.size() != 0) {
			state.numVisits++;
			state = state.getBestChildUCB();
		}

		return state;
	}

	// This is where we find the next move with the highest UCB TBConfirmed
	private GameState expand(GameState state) {

		if (state.isTerminalNode())
			return state;

		GameState newState = null;

		// System.out.println("AVAILABLE ACTIONS: " + state.getActions().get(0));

		for (Tile[] moves : state.getActions()) {
			// TODO add randomness in picking states
			newState = new GameState(state.board2DArray, state.blackQueens, state.whiteQueens, (state.whosTurn % 2) + 1,
					state);
			updateGameBoard(newState.board2DArray, moves);
			updateQueens(moves[0].type == Tile.BLACK ? newState.blackQueens : newState.whiteQueens, moves);
			newState.updateWinner();
			state.addChild(newState);
		}
		
		return state.child.get(new Random().nextInt(state.child.size()));
		// List<state.getMoves()
		// List<GameState> unexploredStates = state.getUnexploredChild();
		// GameState newChild =
		// unexploredStates.get(rand.nextInt(unexploredStates.size()));
		// state.addChild(newChild);
		// return newChild;
	}

	private GameState simulate(GameState state) {
		while (!state.isTerminalNode()) {
			COSC322Test.printBoard(state);

			System.out.println((state.getActions().size()));
			Tile[] randAction = state.getActions().get(new Random().nextInt(state.getActions().size()));
			GameState newState = new GameState(state.board2DArray, state.blackQueens, state.whiteQueens,
					(state.whosTurn % 2) + 1, state);
			updateGameBoard(newState.board2DArray, randAction);
			updateQueens(randAction[0].type == Tile.BLACK ? newState.blackQueens : newState.whiteQueens, randAction);
			newState.updateWinner();
			state = newState;
		}
		return state;
	}

	// method for backpropagation
	private void backpropagate(GameState state, int outcome) {
		while (state != null) {
			state.updateStats(outcome);
			state = state.getParent();
		}
	}

	// this method is to update the board
	public static void updateGameBoard(int[][] gameBoard, Tile[] moves) {
		int queenColor = gameBoard[moves[0].row][moves[0].col];
		gameBoard[moves[0].row][moves[0].col] = Tile.EMPTY;
		gameBoard[moves[1].row][moves[1].col] = moves[0].type;
		gameBoard[moves[2].row][moves[2].col] = Tile.ARROW;
	}

	// update queen position
	public static void updateQueens(List<Tile> queens, Tile[] moves) {
		boolean found = false;
		for (Tile q : queens) {
			if (q.row == moves[0].row && q.col == moves[0].col) {
				found = true;
				q.row = moves[1].row;
				q.col = moves[1].col;
				break;
			}
		}
		if(!found) {
			System.out.println("NOT FOUND");
		}
	}
	// To initialize a state: GameState state = new GameState(...)
	// To create a MCST with n iteration: MonteCarloTreeSearch mcts = new
	// MonteCarloTreeSearch(state, n)
	// To find best move using Monte Carlo: GameState best = mcts.findBestMove();
}
