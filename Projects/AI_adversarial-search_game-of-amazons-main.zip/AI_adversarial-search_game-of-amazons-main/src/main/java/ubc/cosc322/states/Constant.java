package ubc.cosc322.states;

// this class define the constants used in the states
public class Constant {
  public final static int ARROW = 3;
  public final static int BLACK = 2;
  public final static int WHITE = 1;
  public final static int EMPTY = 0;
}
