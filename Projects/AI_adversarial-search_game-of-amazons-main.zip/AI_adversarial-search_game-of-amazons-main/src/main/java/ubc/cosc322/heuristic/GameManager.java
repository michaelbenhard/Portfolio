package ubc.cosc322.heuristic;

import ygraph.ai.smartfox.games.amazons.AmazonsGameMessage;

public class GameManager {
	final int ARROW = 3;
	final int BLACK = 2;
	final int WHITE = 1;
	final int EMPTY = 0;

	private int turnCount;
	private int opponentID;
	private int myID;

	public GameManager() {
		// initGame
	}
}
